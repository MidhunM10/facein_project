import os

# File structure and content
files = {
    "main/__init__.py": "",
    "main/admin.py": "from django.contrib import admin\n",
    "main/apps.py": "from django.apps import AppConfig\n\nclass MainConfig(AppConfig):\n    name = 'main'\n",
    "main/models.py": "",
    "main/tests.py": "",
    "main/views.py": '''from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import RegisterForm, ContactForm

def home(request):
    return render(request, 'main/home.html')

def about(request):
    return render(request, 'main/about.html')

def menu(request):
    return render(request, 'main/menu.html')

def contact(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            messages.success(request, "Thank you for contacting us!")
            return redirect('contact')
    else:
        form = ContactForm()
    return render(request, 'main/contact.html', {'form': form})

@login_required
def dashboard(request):
    return render(request, 'main/dashboard.html')

def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Registration successful. Please log in.")
            return redirect('login')
    else:
        form = RegisterForm()
    return render(request, 'main/register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, "Login successful.")
            return redirect('dashboard')
        else:
            messages.error(request, "Invalid credentials.")
    return render(request, 'main/login.html')

def logout_view(request):
    logout(request)
    messages.info(request, "Logged out successfully.")
    return redirect('home')
''',
    "main/forms.py": '''from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm

class RegisterForm(UserCreationForm):
    email = forms.EmailField(required=True)
    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']

class ContactForm(forms.Form):
    name = forms.CharField(max_length=100)
    email = forms.EmailField()
    message = forms.CharField(widget=forms.Textarea)
''',
    "main/urls.py": '''from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('about/', views.about, name='about'),
    path('contact/', views.contact, name='contact'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('menu/', views.menu, name='menu'),
    path('register/', views.register, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
]
''',
    "main/templates/main/base.html": '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>The Rice Bowl</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="{% static 'main/css/style.css' %}">
</head>
<body>
    <header>
        <div class="logo">
            <img src="{% static 'main/images/logo.png' %}" alt="The Rice Bowl Logo">
            <span>The Rice Bowl</span>
        </div>
        <nav>
            <ul>
                <li><a href="{% url 'home' %}">Home</a></li>
                <li><a href="{% url 'about' %}">About</a></li>
                <li><a href="{% url 'menu' %}">Menu</a></li>
                <li><a href="{% url 'contact' %}">Contact</a></li>
                {% if user.is_authenticated %}
                    <li><a href="{% url 'dashboard' %}">Dashboard</a></li>
                    <li><a href="{% url 'logout' %}">Logout</a></li>
                {% else %}
                    <li><a href="{% url 'login' %}">Login</a></li>
                    <li><a href="{% url 'register' %}">Register</a></li>
                {% endif %}
            </ul>
        </nav>
    </header>
    <div class="container">
        {% if messages %}
            <div class="messages">
                {% for message in messages %}
                    <div class="alert {{ message.tags }}">{{ message }}</div>
                {% endfor %}
            </div>
        {% endif %}
        {% block content %}{% endblock %}
    </div>
    <footer>
        <p>&copy; 2025 The Rice Bowl. All rights reserved.</p>
    </footer>
</body>
</html>
''',
    "main/templates/main/home.html": '''{% extends 'main/base.html' %}
{% block content %}
<div class="hero">
    <div class="hero-text">
        <h1>EXPERIENCE THE FINEST NON-VEG DELICACIES</h1>
        <p>Welcome to The Rice Bowl, where every meal is a celebration of flavor. Enjoy our signature grilled meats, spicy curries, and authentic Asian cuisine in a cozy, modern setting.</p>
        <a href="{% url 'contact' %}" class="btn-primary">Book a Table</a>
    </div>
    <div class="hero-img">
        <img src="{% static 'main/images/hero-dishes.png' %}" alt="Signature Dishes">
    </div>
</div>
{% endblock %}
''',
    "main/templates/main/about.html": '''{% extends 'main/base.html' %}
{% block content %}
<section class="about-section">
    <h2>About The Rice Bowl</h2>
    <p>The Rice Bowl is a family-owned restaurant specializing in non-vegetarian Asian cuisine. Our chefs blend traditional recipes with modern techniques to bring you unforgettable dishes. Whether you crave spicy chicken, tender lamb, or fresh seafood, we have something for every palate.</p>
</section>
{% endblock %}
''',
    "main/templates/main/contact.html": '''{% extends 'main/base.html' %}
{% block content %}
<section class="contact-section">
    <h2>Contact Us</h2>
    <form method="post">
        {% csrf_token %}
        {{ form.as_p }}
        <button type="submit" class="btn-primary">Send Message</button>
    </form>
</section>
{% endblock %}
''',
    "main/templates/main/dashboard.html": '''{% extends 'main/base.html' %}
{% block content %}
<section class="dashboard-section">
    <h2>Welcome, {{ user.username }}!</h2>
    <p>Thank you for being a valued guest at The Rice Bowl. Check out our latest menu updates and exclusive offers just for you.</p>
</section>
{% endblock %}
''',
    "main/templates/main/menu.html": '''{% extends 'main/base.html' %}
{% block content %}
<section class="menu-section">
    <h2>Our Menu</h2>
    <ul class="menu-list">
        <li>
            <h3>Grilled Chicken Platter</h3>
            <p>Juicy grilled chicken served with aromatic rice and spicy sauce.</p>
        </li>
        <li>
            <h3>Spicy Lamb Curry</h3>
            <p>Tender lamb cooked in a rich, spicy gravy. Served with naan or rice.</p>
        </li>
        <li>
            <h3>Seafood Noodles</h3>
            <p>Stir-fried noodles with prawns, squid, and fresh vegetables.</p>
        </li>
    </ul>
</section>
{% endblock %}
''',
    "main/templates/main/register.html": '''{% extends 'main/base.html' %}
{% block content %}
<section class="auth-section">
    <h2>Register</h2>
    <form method="post">
        {% csrf_token %}
        {{ form.as_p }}
        <button type="submit" class="btn-primary">Register</button>
    </form>
</section>
{% endblock %}
''',
    "main/templates/main/login.html": '''{% extends 'main/base.html' %}
{% block content %}
<section class="auth-section">
    <h2>Login</h2>
    <form method="post">
        {% csrf_token %}
        <label for="username">Username:</label>
        <input type="text" name="username" required>
        <label for="password">Password:</label>
        <input type="password" name="password" required>
        <button type="submit" class="btn-primary">Login</button>
    </form>
</section>
{% endblock %}
''',
    "main/static/main/css/style.css": '''body {
    margin: 0;
    font-family: 'Segoe UI', Arial, sans-serif;
    background: #181818;
    color: #fff;
}
header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: #111;
    padding: 1rem 2rem;
}
.logo {
    display: flex;
    align-items: center;
}
.logo img {
    width: 40px;
    margin-right: 10px;
}
.logo span {
    font-size: 1.5rem;
    font-weight: bold;
    color: #FFD700;
}
nav ul {
    list-style: none;
    display: flex;
    gap: 2rem;
    margin: 0;
    padding: 0;
}
nav a {
    color: #fff;
    text-decoration: none;
    font-weight: 600;
    letter-spacing: 1px;
    transition: color 0.2s;
}
nav a:hover {
    color: #FFD700;
}
.hero {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: space-between;
    background: url('../images/black-bg.jpg') no-repeat center center/cover;
    padding: 3rem 2rem;
    min-height: 60vh;
}
.hero-text {
    flex: 1 1 350px;
    max-width: 500px;
}
.hero-text h1 {
    font-size: 3rem;
    font-weight: bold;
    margin-bottom: 1rem;
    color: #fff;
}
.hero-text p {
    font-size: 1.2rem;
    margin-bottom: 2rem;
}
.btn-primary {
    background: #FFD700;
    color: #111;
    padding: 0.8rem 2rem;
    border: none;
    border-radius: 4px;
    font-weight: bold;
    text-decoration: none;
    transition: background 0.2s;
}
.btn-primary:hover {
    background: #e6c200;
}
.hero-img img {
    width: 350px;
    border-radius: 50%;
    box-shadow: 0 0 30px #000;
}
.container {
    max-width: 1000px;
    margin: 2rem auto;
    padding: 0 1rem;
}
footer {
    background: #111;
    color: #FFD700;
    text-align: center;
    padding: 1rem 0;
    margin-top: 2rem;
}
.messages {
    margin: 1rem 0;
}
.alert {
    padding: 1rem;
    border-radius: 4px;
    margin-bottom: 1rem;
}
.alert.success { background: #28a745; color: #fff; }
.alert.error { background: #dc3545; color: #fff; }
.alert.info { background: #17a2b8; color: #fff; }
@media (max-width: 900px) {
    .hero {
        flex-direction: column;
        text-align: center;
    }
    .hero-img img {
        margin-top: 2rem;
        width: 250px;
    }
}
@media (max-width: 600px) {
    header, .container {
        padding: 1rem;
    }
    .hero-text h1 {
        font-size: 2rem;
    }
    nav ul {
        flex-direction: column;
        gap: 1rem;
    }
}
''',
}

# Create folders and files
for path, content in files.items():
    folder = os.path.dirname(path)
    if not os.path.exists(folder):
        os.makedirs(folder)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)

# Create empty images folder
os.makedirs("main/static/main/images", exist_ok=True)

print("All files and folders created!")
print("Now add your images (logo.png, hero-dishes.png, black-bg.jpg) to main/static/main/images/")
print("Don't forget to add 'main' to INSTALLED_APPS and configure static/templates dirs in settings.py.")